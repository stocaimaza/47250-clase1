export const sumar = (numeroA, numeroB) => numeroA + numeroB;

export const resta = (numeroA, numeroB) => numeroA - numeroB;

//También si quieren evitar colocar la palabra "export" pueden escribir al final: 

//export {sumar, resta};