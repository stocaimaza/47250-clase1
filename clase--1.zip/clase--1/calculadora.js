import { sumar } from "./operaciones.js";

console.log(sumar(150, 50));